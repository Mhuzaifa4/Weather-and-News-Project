package com.aizaz.top.bbc.flutter_news_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
